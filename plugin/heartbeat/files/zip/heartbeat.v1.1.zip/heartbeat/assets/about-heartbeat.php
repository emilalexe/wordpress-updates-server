<?php ?>
<div class="heartbeat-setup-template">
    <h1 class="heartbeat-bold-h1 beatHeartTitle heartbeat-clear-div33">
        <i class="heartbeat-heartbeat beatHeart"></i> <?php
        if ( ! function_exists( 'get_plugins' ) ) {
            require_once ABSPATH . 'wp-admin/includes/plugin.php';
        }
        $all_plugins = get_plugins( '/heartbeat/');
        $plugin_version = $all_plugins['heartbeat_functions.php']['Version'];
        echo __('About','heartbeat_domain').' '.__("HeartBeat").'<sub class="heartbeat-bold-h1-sub"> v '.$plugin_version.'</sub>'; ?>
    </h1>
    <hr>
</div>
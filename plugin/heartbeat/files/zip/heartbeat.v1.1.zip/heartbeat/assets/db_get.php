<?php
$wp_config_path = get_home_path();
if($wp_config_path != ""){
    $path = $wp_config_path;
    include_once $path . '/wp-config.php';
}
else {
    $path = $_SERVER['DOCUMENT_ROOT'];
    $filename = $path . '/wp-config.php';
    if (file_exists($filename)) {
        include_once $filename;
    } else {
        $path1 = explode("/",$path);
        unset($path1[count($path)-1]);
        $path1 = implode("/",$path1);
        $filename = $path1 . '/wp-config.php';
        include_once $filename;
    }
}

include_once $path . '/wp-load.php';
include_once $path . '/wp-includes/wp-db.php';
include_once $path . '/wp-includes/pluggable.php';
global $wpdb;

if(isset($_POST['heartbeat_id'])){
    $prefix = $wpdb->prefix;
    $data = $wpdb->get_row("SELECT * FROM  ".$prefix."heartbeat WHERE id = '".$_POST['heartbeat_id']."';");
    $result = json_encode($data);
}
else{
    $prefix = $wpdb->prefix;
    $data = $wpdb->get_results("SELECT * FROM  ".$prefix."heartbeat;");
    $result = json_encode($data);
}
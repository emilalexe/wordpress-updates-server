<?php
require_once '../wpconfigpath.php';
if($wp_config_path != ""){
    $path = $wp_config_path;
    include_once $path . '/wp-config.php';
}
else {
    $path = $_SERVER['DOCUMENT_ROOT'];
    $filename = $path . '/wp-config.php';
    if (file_exists($filename)) {
        include_once $filename;
    } else {
        $path1 = explode("/",$path);
        unset($path1[count($path)-1]);
        $path1 = implode("/",$path1);
        $filename = $path1 . '/wp-config.php';
        include_once $filename;
    }
}
include_once $path . '/wp-load.php';
include_once $path . '/wp-includes/wp-db.php';
include_once $path . '/wp-includes/pluggable.php';
global $wpdb;

$user = wp_get_current_user();
$allowed_roles = array('editor', 'administrator', 'author');
if( !array_intersect($allowed_roles, $user->roles ) ) {
    echo 'Hi there!  I\'m just a plugin, not much I can do when called directly.';
    exit;
}

if(isset($_POST['heartbeat_id'])){
    $wpdb->insert(
        $prefix."heartbeat",
        array(
            'id'              => $_POST['id'],
            'visible'         => $_POST['visible'],
            'type'            => $_POST['type'],
            'min_data'        => $_POST['min-data']
        )
    );

    $id = $wpdb->get_row("SELECT * FROM ".$prefix."heartbeat ORDER BY id DESC LIMIT 1;");

    echo $id->id;
}
?>
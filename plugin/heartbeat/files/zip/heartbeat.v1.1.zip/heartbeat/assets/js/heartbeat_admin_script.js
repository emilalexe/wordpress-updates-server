/**
 * Created by Emil on 4/22/2017.
 */
( function( wp ) {
    var checked = jQuery("input[name*='visible']:checked").length;
    //alert(checked);

    if (checked == 0) {
        jQuery(".heartbeat-condition").hide();
        return false;
    } else {
        jQuery(".heartbeat-condition").show();
        return true;
    }

} )(
    window.wp
);
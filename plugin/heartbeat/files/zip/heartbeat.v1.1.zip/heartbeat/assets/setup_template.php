<?php
global $heartbeat_debug;
if(isset($_POST["heartbeat"]))
{
    modify_settings($_POST);
}
require_once 'db_get.php';
if(!$result == 'null'){
    header('Location: ?page=heartbeat-add');
}
else{
    $heartbeat_datas = json_decode($result, true)[0];
    if( $heartbeat_debug){
        echo '<div class="heartbeat-debug">';
        if(isset($heartbeat_datas) && sizeof($heartbeat_datas) > 0 ) {
            echo "DEBUG: heartbeat_datas -> ";
            print_r($heartbeat_datas);
        }
        echo '</div>';
    }
}
?>
<div class="heartbeat-setup-template">
    <h1 class="heartbeat-bold-h1 beatHeartTitle heartbeat-clear-div33">
        <i class="heartbeat-heartbeat beatHeart"></i> <?php
        if ( ! function_exists( 'get_plugins' ) ) {
            require_once ABSPATH . 'wp-admin/includes/plugin.php';
        }
        $all_plugins = get_plugins( '/heartbeat/');
        $plugin_version = $all_plugins['heartbeat_functions.php']['Version'];
        echo __("HeartBeat").'<sub class="heartbeat-bold-h1-sub"> v '.$plugin_version.'</sub>'; ?>
    </h1>
    <div id="heartbeat-clear-message"></div>
    <hr class="heartbeat-clear-div100">
    <div class="heartbeat-clear-div100">
        <div class="heartbeat-clear-container heartbeat-clear-div100">
            <form id="heartbeat-settings" target="" method="post">
                <div class="heartbeat-clear-div100 heartbeat-label">
                    <?php _e('Visible with condition','heartbeat_domain'); ?>
                    <input type="checkbox" name="visible" value="1"
                           <?php
                           if(isset($heartbeat_datas['visible']) && $heartbeat_datas['visible']==1){
                               echo ' checked ';
                           }
                               ?>/>
                </div>
                <div class="heartbeat-clear-div100 heartbeat-condition" style="display: block;">
                    <div class="heartbeat-clear-div100 heartbeat-label">
                        <?php _e('IF visitors number <= ','heartbeat_domain'); ?>
                        <input type="number" name="min-data" min="1" value="<?php
                        if(isset($heartbeat_datas['min_data'])){
                            echo $heartbeat_datas['min_data'];
                        }else{
                            echo '1';
                        }
                        ?>">
                        <?php _e('THEN show','heartbeat_domain'); ?>
                        <select name="type">
                            <option value="real-data"
                            <?php if(isset($heartbeat_datas['type']) && $heartbeat_datas['type']=="real-data" ){
                                echo " selected ";
                            }?>><?php _e('real visitors','heartbeat_domain'); ?></option>
                            <option value="fake-data"<?php if(isset($heartbeat_datas['type']) && $heartbeat_datas['type']=="fake-data" ){
                                echo " selected ";
                            }?>><?php _e('fake visitors','heartbeat_domain'); ?></option>
                        </select>
                    </div>
                </div>
                <input class="button" type="submit" name="heartbeat" value="<?php _e('Submit','heartbeat_domain'); ?>">
            </form>
        </div>
    </div>
</div>